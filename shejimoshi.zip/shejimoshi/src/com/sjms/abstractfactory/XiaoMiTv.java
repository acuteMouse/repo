package com.sjms.abstractfactory;
//小米电视的实现
public class XiaoMiTv extends TV {

	@Override
	public void show() {
		System.out.println("小米TV");

	}

}
