package com.sjms.abstractfactory;
//定义手机抽象类
public abstract class Phone {
		public abstract  void getName();
}
