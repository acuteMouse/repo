package com.sjms.abstractfactory;
//小米手机的实现
public class XiaoMiPhone extends Phone {

	@Override
	public void getName() {
		System.out.println("小米手机");

	}

}
