package com.sjms.abstractfactory;
//定义电视抽象类
public abstract class TV {
		public abstract void show();
}
