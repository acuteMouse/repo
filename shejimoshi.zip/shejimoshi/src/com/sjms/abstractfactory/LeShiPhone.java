package com.sjms.abstractfactory;
//乐视手机的实现
public class LeShiPhone extends Phone {

	@Override
	public void getName() {
		System.out.println("乐视手机");

	}

}
