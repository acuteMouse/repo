package com.sjms.abstractfactory;
//乐视电视的实现
public class LeShiTV extends TV {

	@Override
	public void show() {
		System.out.println("乐视TV");
	}

}
