package com.sjms.simpleFactory;

public class Audi implements Car {

	@Override
	public void Run() {
		System.out.println("奥迪。。。。");

	}

}
