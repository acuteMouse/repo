package com.sjms.simpleFactory;

public class Benz implements Car {

	@Override
	public void Run() {
		System.out.println("奔驰。。。。");
	}

}
