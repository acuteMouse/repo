package com.sjms.simpleFactory;

public class BMW implements Car {

	@Override
	public void Run() {
		System.out.println("宝马。。。。");
		

	}

}
