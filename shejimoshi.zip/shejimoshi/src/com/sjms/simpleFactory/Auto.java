package com.sjms.simpleFactory;

public class Auto implements Car {

	@Override
	public void Run() {
			System.out.println("奥拓。。。");
	}

}
