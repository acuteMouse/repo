package com.sjms.simpleFactory;

public interface Car {
		public void Run();
}
