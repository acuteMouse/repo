package com.sjms.factory;
//奔驰的具体实现
public class Benz implements Car {

	@Override
	public void run() {
		System.out.println("奔驰。。。。");

	}

}
