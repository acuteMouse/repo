package com.sjms.factory;

//定义汽车借口
public interface Car {
	public void run();
}
