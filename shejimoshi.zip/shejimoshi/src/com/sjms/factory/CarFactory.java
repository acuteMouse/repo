package com.sjms.factory;

//工厂借口
public interface CarFactory {
	public Car getCar();	//生成汽车方法
}
