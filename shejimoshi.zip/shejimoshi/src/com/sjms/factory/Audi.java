package com.sjms.factory;

//奥迪的具体实现
public class Audi implements Car {

	@Override
	public void run() {
		System.out.println("奥迪。。。");

	}

}
