package com.jhsy.dao;

import com.jhsy.model.ProductIn;

public abstract interface BuyProductDao
{
  public abstract void add(ProductIn paramProductIn);
}

/* Location:           G:\study\jianhangsuye\WEB-INF\classes\
 * Qualified Name:     com.jhsy.dao.BuyProductDao
 * JD-Core Version:    0.6.2
 */